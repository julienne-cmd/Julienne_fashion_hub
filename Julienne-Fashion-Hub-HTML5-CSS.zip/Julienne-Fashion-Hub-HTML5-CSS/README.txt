JULIENNE FASHION HUB — HTML5 + CSS3 VERSION

PROJECT OVERVIEW
This is the standalone HTML5, CSS3 and vanilla JavaScript frontend for Julienne Fashion Hub. It is the HTML/CSS implementation of the same fashion-store project that is also presented in a separate React version.

TECHNOLOGIES
- HTML5: semantic website structure and page content
- CSS3: layout, typography, colours, responsive design and visual styling
- Vanilla JavaScript: navigation, product filtering, product details, size selection, shopping-bag counter and contact-form demonstration

WEBSITE SECTIONS
- Home page and featured products
- Shop page with category filters
- Individual product details and size selection
- About page with mission and vision
- Contact page with a demonstration form

PROJECT FILES
- index.html — main HTML5 document
- css/style.css — all CSS styling
- js/script.js — product data and interactive features

HOW TO VIEW
1. Extract this ZIP archive on a computer or use a ZIP/file manager app on a phone.
2. Open the Julienne-Fashion-Hub-HTML5-CSS folder.
3. Open index.html in a modern browser.
4. For development, open the folder in Visual Studio Code and use Live Server.

NOTES FOR PRESENTATION
This is the HTML5/CSS3/JavaScript version. Keep it separate from the React version so the lecturer can assess both implementations independently. The contact form is a frontend demo and does not send messages to a server. Product photographs and Google Fonts are loaded from online sources, so internet access is needed for those assets.
